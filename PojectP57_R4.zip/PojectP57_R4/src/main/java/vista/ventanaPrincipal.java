package vista;

import java.awt.event.*;
import javax.swing.*;
import controlador.ControladorRequerimientos;

public class ventanaPrincipal extends JFrame implements ActionListener {

    //Atributos
    private JTextArea areaIntroduccion;
    private JLabel labelTitulo;
    private JButton botonInforme, Agregar_lider;
    private ControladorRequerimientos controlador;

    //Constructor
    public ventanaPrincipal(){

        //Instanciar el controlador
        controlador = new ControladorRequerimientos();

        //Configuración JFrame
        setSize(480,350);
        setTitle("Mision TIC 2022");
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        //Label Titulo
        labelTitulo = new JLabel("RETO 5 - PATRON M.V.C");
        labelTitulo.setBounds(60,40,380,30);
        labelTitulo.setFont(new java.awt.Font("Verdana",1,15));
        add(labelTitulo);

        //TextArea
        areaIntroduccion = new JTextArea("Aplicación MVC - MISION TIC 2022 \n Interfaz grafica Reto 5");
        areaIntroduccion.setBounds(50,90,380,140);
        areaIntroduccion.setEditable(false);
        areaIntroduccion.setFont(new java.awt.Font("Verdana",0,14));
        add(areaIntroduccion);

        //Boton Informe
        botonInforme = new JButton("Informe Requerimientos");
        botonInforme.setBounds(50, 250, 180, 25);
        add(botonInforme);
        botonInforme.addActionListener(this);

        //Boton Nuevo lider
        Agregar_lider = new JButton("Agregar un nuevo Lider");
        Agregar_lider.setBounds(250, 250, 180, 25);
        add(Agregar_lider);
        Agregar_lider.addActionListener(this);

    }

    //Metodo
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == botonInforme){
            controlador.Mostrar_ventanaInforme();
        }
        else{
            controlador.Mostrar_ventanaNuevoLider();
        }

    }

}

