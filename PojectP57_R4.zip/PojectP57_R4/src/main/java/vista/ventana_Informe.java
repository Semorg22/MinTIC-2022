package vista;

import java.awt.event.*;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;
import controlador.ControladorRequerimientos;
import modelo.vo.*;

public class ventana_Informe extends JFrame implements ActionListener{

    //Atributos
    private JTextArea areaIntroduccion;
    private JLabel labelTitulo;
    private JButton Req1, Req2;
    private ControladorRequerimientos controlador;
    private JScrollPane scroll_bar;

    //Constructor
    public ventana_Informe(){

        //Instanciar el controlador
        controlador = new ControladorRequerimientos();

        //Configuración JFrame
        setSize(480,350);
        setTitle("Mision TIC 2022");
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);

        //Label Titulo
        labelTitulo = new JLabel("Informe de Requerimientos");
        labelTitulo.setBounds(60,10,380,30);
        labelTitulo.setFont(new java.awt.Font("Verdana",1,15));
        add(labelTitulo);

        //TextArea
        areaIntroduccion = new JTextArea("");
        areaIntroduccion.setEditable(false);
        areaIntroduccion.setFont(new java.awt.Font("Verdana",0,14));
        scroll_bar = new JScrollPane(areaIntroduccion);
        scroll_bar.setBounds(50,55,380,180);
        add(scroll_bar);

        //Boton Informe
        Req1 = new JButton("Requerimiento 1");
        Req1.setBounds(50, 250, 180, 25);
        add(Req1);
        Req1.addActionListener(this);

        //Boton Nuevo lider
        Req2 = new JButton("Requerimiento 2");
        Req2.setBounds(250, 250, 180, 25);
        add(Req2);
        Req2.addActionListener(this);

    }


    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == Req1){
            ArrayList<Requerimiento_1Vo> lista_final = new ArrayList<Requerimiento_1Vo>();
            String final_final = "";
            try {
                lista_final = controlador.consultarRequerimiento1();
                for(Requerimiento_1Vo s : lista_final){
                    final_final += s + "\n";
                }
            }
            catch (SQLException e1) {
                e1.printStackTrace();
            }    
            areaIntroduccion.setText(final_final);
        }
        else{
            ArrayList<Requerimiento_2Vo> lista_final = new ArrayList<Requerimiento_2Vo>();
            String final_final = "";
            try {
                lista_final = controlador.consultarRequerimiento2();
                for(Requerimiento_2Vo s : lista_final){
                    final_final += s + "\n";
                }
            } 
            catch (SQLException e1) {
                e1.printStackTrace();
            }    
            areaIntroduccion.setText(final_final);
        }
    }
}
