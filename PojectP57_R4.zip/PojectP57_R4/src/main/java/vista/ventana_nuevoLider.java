package vista;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import util.*;

public class ventana_nuevoLider extends JFrame implements ActionListener {

    //Atributos
	private JTextField textId_lider, textNombre, textPrimer_apell, textSegundo_apell, textSalario, textCiudad, textCargo, textClasif, textDoc_id, textFecha_Nac;
	private JLabel Id_lider, Nombre, Primer_apell, Segundo_apell, Salario, Ciudad, Cargo, Clasif, Doc_id, Fecha_Nac, Formato, textFormato;
	private JButton botonInsertar, botonCancelar, botonLimpiar;
    
    //Constructor
    public ventana_nuevoLider(){

        // Configuración de la ventana (JFrame)
		setSize(420, 550);
		setTitle("Mision TIC 2022");
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);

		//LABEL Y TEXTFIELD

		Id_lider = new JLabel("ID Lider");
		Id_lider.setBounds(12, 20, 120, 25);
		add(Id_lider);
		textId_lider = new JTextField();
		textId_lider.setBounds(160, 20, 210, 25);
		add(textId_lider);

		Nombre = new JLabel("Nombre");
		Nombre.setBounds(12, 60, 120, 25);
		add(Nombre);
		textNombre = new JTextField();
		textNombre.setBounds(160, 60, 210, 25);
		add(textNombre);

		Primer_apell = new JLabel("Primer Apellido");
		Primer_apell.setBounds(12, 100, 120, 25);
		add(Primer_apell);
		textPrimer_apell = new JTextField();
		textPrimer_apell.setBounds(160, 100, 210, 25);
		add(textPrimer_apell);

		Segundo_apell = new JLabel("Segundo Apellido");
		Segundo_apell.setBounds(12, 140, 120, 25);
		add(Segundo_apell);
		textSegundo_apell = new JTextField();
		textSegundo_apell.setBounds(160, 140, 210, 25);
		add(textSegundo_apell);

		Salario = new JLabel("Salario");
		Salario.setBounds(12, 180, 120, 25);
		add(Salario);
		textSalario = new JTextField();
		textSalario.setBounds(160, 180, 210, 25);
		add(textSalario);

		Ciudad = new JLabel("Ciudad Residencia");
		Ciudad.setBounds(12, 220, 120, 25);
		add(Ciudad);
		textCiudad = new JTextField();
		textCiudad.setBounds(160, 220, 210, 25);
		add(textCiudad);

		Cargo = new JLabel("Cargo");
		Cargo.setBounds(12, 260, 120, 25);
		add(Cargo);
		textCargo = new JTextField();
		textCargo.setBounds(160, 260, 210, 25);
		add(textCargo);

		Clasif = new JLabel("Clasificación");
		Clasif.setBounds(12, 300, 120, 25);
		add(Clasif);
		textClasif = new JTextField();
		textClasif.setBounds(160, 300, 210, 25);
		add(textClasif);

		Doc_id = new JLabel("Doc. Identidad");
		Doc_id.setBounds(12, 340, 120, 25);
		add(Doc_id);
		textDoc_id = new JTextField();
		textDoc_id.setBounds(160, 340, 210, 25);
		add(textDoc_id);

		Fecha_Nac = new JLabel("Fecha de Nacimiento");
		Fecha_Nac.setBounds(12, 380, 120, 25);
		add(Fecha_Nac);
		textFecha_Nac = new JTextField();
		textFecha_Nac.setBounds(160, 380, 210, 25);
		add(textFecha_Nac);

		Formato = new JLabel("Formato de fecha");
		Formato.setBounds(12, 420, 120, 25);
		add(Formato);
		textFormato = new JLabel("AÑO - MES - DIA 	    (Ingresar tal cual)");
		textFormato.setBounds(160, 420, 210, 25);
		add(textFormato);

		// Botones
		botonInsertar = new JButton("Insertar");
		botonInsertar.setBounds(40, 460, 100, 25);
		add(botonInsertar);
		botonInsertar.addActionListener(this);

		botonCancelar = new JButton("Cancelar");
		botonCancelar.setBounds(150, 460, 100, 25);
		add(botonCancelar);
		botonCancelar.addActionListener(this);

		botonLimpiar = new JButton("Limpiar");
		botonLimpiar.setBounds(260, 460, 100, 25);
		add(botonLimpiar);
		botonLimpiar.addActionListener(this);

        // Llamado al método para limpiar campos
		limpiar();

    }

    //Metodos
    public void actionPerformed(ActionEvent e) {
		if(e.getSource() == botonInsertar){

			int ID_Lider = Integer.parseInt(textId_lider.getText());
			String Nombre = textNombre.getText();
			String Primer_Apellido = textPrimer_apell.getText();
			String Segundo_Apelido = textSegundo_apell.getText();
			int Salario = Integer.parseInt(textSalario.getText()); 
			String Ciudad = textCiudad.getText();
			String Cargo = textCargo.getText();
			double Clasificacion = Double.parseDouble(textClasif.getText());
			String Doc_id = textDoc_id.getText();
			String Fecha_Nacimiento = textFecha_Nac.getText();
			
			int resultado = PreparadaInsertar(ID_Lider, Nombre, Primer_Apellido, Segundo_Apelido, Salario, Ciudad, Cargo, Clasificacion, Doc_id, Fecha_Nacimiento);

			if(resultado>0){
				JOptionPane.showMessageDialog(null, "Se agrego un nuevo lider con exito","Informacion",JOptionPane.INFORMATION_MESSAGE);
				System.out.println("Se inserto en la base de datos");
				limpiar();
			}
			else{
				JOptionPane.showMessageDialog(null, "No se agrego un nuevo lider, revise que los datos sean correctos o que no hagan parte de la base de datos","Advertencia",JOptionPane.WARNING_MESSAGE);
			}
		}
		if(e.getSource() == botonLimpiar){
            limpiar();
        }
        if(e.getSource() == botonCancelar){
            this.dispose(); //cerrar la ventana
        }
    }

	public int PreparadaInsertar(int ID_lider, String Nombre, String Primer_Apellido, String Segundo_Apelido, int Salario, String Ciudad, String Cargo, double Clasificacion, String Doc_id, String Fecha_Nacimiento){
		int columnas = 0;
		try{
			Connection conn = JDBCUtilities.getConnection();
			String sql = "insert into Lider (ID_Lider, Nombre, Primer_Apellido, Segundo_Apellido, Salario, Ciudad_Residencia, Cargo, Clasificacion, Documento_Identidad, Fecha_Nacimiento) values (?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstm = conn.prepareStatement(sql);
			pstm.setInt(1, ID_lider);
			pstm.setString(2, Nombre);
			pstm.setString(3, Primer_Apellido);
			pstm.setString(4, Segundo_Apelido);
			pstm.setInt(5, Salario);
			pstm.setString(6, Ciudad);
			pstm.setString(7, Cargo);
			pstm.setDouble(8, Clasificacion);
			pstm.setString(9, Doc_id);
			pstm.setString(10, Fecha_Nacimiento);
			columnas = pstm.executeUpdate();

			pstm.close();
		} 
		catch (SQLException e) {
			System.out.println("Ocurrio un error en metodo preparada insertar");
			e.printStackTrace();
			System.out.println(e);
		}
		return columnas;
		
	}

    public void limpiar() {
		textId_lider.setText("");
		textNombre.setText("");
		textPrimer_apell.setText("");
		textSegundo_apell.setText("");
		textSalario.setText("");
		textCiudad.setText("");
		textCargo.setText("");
		textClasif.setText("");
		textDoc_id.setText("");
		textFecha_Nac.setText("");
	} 
}