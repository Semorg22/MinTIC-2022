package controlador;

import java.sql.SQLException;
import java.util.ArrayList;
import modelo.dao.*;
import modelo.vo.*;
import vista.*;

public class ControladorRequerimientos {
    
    //Atributos
    private Requerimiento_1Dao req1_dao;
    private Requerimiento_2Dao req2_dao;
    private Requerimiento_3Dao req3_dao;

    //Constructor
    public ControladorRequerimientos() {
        this.req1_dao = new Requerimiento_1Dao();
        this.req2_dao = new Requerimiento_2Dao();
        this.req3_dao = new Requerimiento_3Dao();
    }

    //Metodos
    public static void Mostrar_ventanaPrincipal(){
        ventanaPrincipal ventana1 = new ventanaPrincipal();
        ventana1.setVisible(true); 
    }
    public void Mostrar_ventanaInforme(){
        ventana_Informe ventana2 = new ventana_Informe();
        ventana2.setVisible(true); 
    }
    public void Mostrar_ventanaNuevoLider(){
        ventana_nuevoLider ventana3 = new ventana_nuevoLider();
        ventana3.setVisible(true); 
    }

    public ArrayList<Requerimiento_1Vo> consultarRequerimiento1() throws SQLException {
        return this.req1_dao.requerimiento1();
    }

    public ArrayList<Requerimiento_2Vo> consultarRequerimiento2() throws SQLException {
        return this.req2_dao.requerimiento2();
    }

    public ArrayList<Requerimiento_3Vo> consultarRequerimiento3() throws SQLException {
        return this.req3_dao.requerimiento3();
    }
}
