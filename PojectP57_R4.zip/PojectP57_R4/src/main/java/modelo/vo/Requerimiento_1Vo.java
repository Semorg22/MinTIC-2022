package modelo.vo;

public class Requerimiento_1Vo {

    //Atributos
    private int id_lider;
    private int salario;
    private String ciudad;

    //Constructor
    public Requerimiento_1Vo(){
    }

    //Getters and Setters
    public int getId_lider() {
        return id_lider;
    }
    public void setId_lider(int id_lider) {
        this.id_lider = id_lider;
    }

    public int getSalario() {
        return salario;
    }
    public void setSalario(int salario) {
        this.salario = salario;
    }

    public String getCiudad() {
        return ciudad;
    }
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    //ToString
    public String toString() {
        return id_lider + " " + salario + " " + ciudad;
    }
}
