package modelo.vo;

public class Requerimiento_3Vo {
    
    //Atributos
    private int clasificacion;
    private int promedio;

    //Constructor
    public Requerimiento_3Vo() {
    }

    //Getters y Setters
    public int getClasificacion() {
        return clasificacion;
    }
    public void setClasificacion(int clasificacion) {
        this.clasificacion = clasificacion;
    }
    
    public int getPromedio() {
        return promedio;
    }
    public void setPromedio(int promedio) {
        this.promedio = promedio;
    }

    //To String
    public String toString() {
        return clasificacion + " " + promedio;
    }

    
}
