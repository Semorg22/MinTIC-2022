package modelo.vo;

public class Requerimiento_2Vo {

    //Atributos
    private int id_proy;
    private String nombre_mat;
    private int precio_u;

    //Constructor
    public Requerimiento_2Vo() {
    }

    //Getters y Setters
    public int getId_proy() {
        return id_proy;
    }
    public void setId_proy(int id_proy) {
        this.id_proy = id_proy;
    }

    public String getNombre_mat() {
        return nombre_mat;
    }
    public void setNombre_mat(String nombre_mat) {
        this.nombre_mat = nombre_mat;
    }

    public int getPrecio_u() {
        return precio_u;
    }
    public void setPrecio_u(int precio_u) {
        this.precio_u = precio_u;
    }

    //To String
    public String toString() {
        return id_proy + " " + nombre_mat + " " + precio_u;
    }
    
}
