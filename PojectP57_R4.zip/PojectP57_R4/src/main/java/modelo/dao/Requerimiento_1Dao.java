package modelo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelo.vo.Requerimiento_1Vo;
import util.JDBCUtilities;

public class Requerimiento_1Dao {

    //Metodo
    public ArrayList<Requerimiento_1Vo> requerimiento1() throws SQLException {
        Connection conexion = JDBCUtilities.getConnection();
        ArrayList<Requerimiento_1Vo> lista_tabla_1 = new ArrayList<Requerimiento_1Vo>();
        String sql = "SELECT l.ID_Lider, l.Salario, l.Ciudad_Residencia FROM Lider l WHERE l.Salario < (SELECT AVG(Salario) FROM Lider l) ORDER BY Salario ASC;";

        try(Statement stm = conexion.createStatement(); ResultSet rs = stm.executeQuery(sql)){
            while(rs.next()){
                Requerimiento_1Vo req1 = new Requerimiento_1Vo();
                req1.setId_lider(rs.getInt("ID_Lider"));
                req1.setSalario(rs.getInt("Salario"));
                req1.setCiudad(rs.getString("Ciudad_Residencia"));
                lista_tabla_1.add(req1);
            }
        }
        return lista_tabla_1;
    }
}