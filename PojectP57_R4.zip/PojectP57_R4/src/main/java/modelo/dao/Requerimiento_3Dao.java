package modelo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelo.vo.Requerimiento_3Vo;
import util.JDBCUtilities;

public class Requerimiento_3Dao {

    //Metodo
    public ArrayList<Requerimiento_3Vo> requerimiento3() throws SQLException {
        Connection conexion = JDBCUtilities.getConnection();
        ArrayList<Requerimiento_3Vo> lista_tabla_3 = new ArrayList<Requerimiento_3Vo>();
        String sql = "SELECT l.Clasificacion, AVG(Salario) as Promedio FROM Lider l GROUP BY l.Clasificacion HAVING AVG(Salario)>400000 ORDER BY Promedio DESC ;";
        
        try(Statement stm = conexion.createStatement(); ResultSet rs = stm.executeQuery(sql)){
            while(rs.next()){
                Requerimiento_3Vo req3 = new Requerimiento_3Vo();
                req3.setClasificacion(rs.getInt("Clasificacion"));
                req3.setPromedio(Math.round(rs.getInt("Promedio")));
                lista_tabla_3.add(req3);
            }
        }
        return lista_tabla_3;
    }
}