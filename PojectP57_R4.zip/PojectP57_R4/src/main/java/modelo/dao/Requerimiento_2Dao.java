package modelo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelo.vo.Requerimiento_2Vo;
import util.JDBCUtilities;

public class Requerimiento_2Dao {

    //Metodo
    public ArrayList<Requerimiento_2Vo> requerimiento2() throws SQLException {
        Connection conexion = JDBCUtilities.getConnection();
        ArrayList<Requerimiento_2Vo> lista_tabla_2 = new ArrayList<Requerimiento_2Vo>(); 
        String sql = "SELECT p.ID_Proyecto, mc.Nombre_Material, mc.Precio_Unidad FROM Proyecto p JOIN Compra c ON (p.ID_Proyecto=c.ID_Proyecto) JOIN MaterialConstruccion mc ON (c.ID_MaterialConstruccion=mc.ID_MaterialConstruccion) WHERE p.ID_Proyecto IN (23,38,50) ORDER BY p.ID_Proyecto ASC;";

        try(Statement stm = conexion.createStatement(); ResultSet rs = stm.executeQuery(sql)){
            while(rs.next()){
                Requerimiento_2Vo req2 = new Requerimiento_2Vo();
                req2.setId_proy(rs.getInt("ID_Proyecto"));
                req2.setNombre_mat(rs.getString("Nombre_Material"));
                req2.setPrecio_u(rs.getInt("Precio_Unidad"));
                lista_tabla_2.add(req2);
            }
        }
        return lista_tabla_2;
    }
}