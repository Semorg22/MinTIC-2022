import controlador.ControladorRequerimientos;
import vista.VistaRequerimientos;

public class App {
    public static void main(String[] args) {

        ControladorRequerimientos.Mostrar_ventanaPrincipal();

        System.out.println("Requerimiento 1");
        VistaRequerimientos.requerimiento1();
        System.out.println();
        
        System.out.println("Requerimiento 2");
        VistaRequerimientos.requerimiento2();
        System.out.println();

        System.out.println("Requerimiento 3");
        VistaRequerimientos.requerimiento3();
        
    }
}
